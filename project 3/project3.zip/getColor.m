function color = getColor( mood )
%Assigns a color to a mood. The colors are chosen
%based on Cynthia Brewer's Color Brewer (colorbrewer2.com)
%Inputs: mood is a real number between [-1,1]
%Returns: if mood is in the range [-1,1] a 1x3 color value from SENTIMENT_COLORS 
%otherwise it returns GRAY


SENTIMENT_COLORS = { [0.1922 0.2118 0.5843], ...
    [0.2706 0.4588 0.7059], ...
    [0.4549 0.6784 0.8196], ...
    [0.6706 0.8510 0.9137], ...
    [0.8784 0.9529 0.9725], ...
    [1.0000 1.0000 0.7490], ...
    [0.9961 0.8784 0.5647], ...
    [0.9922 0.6824 0.3804], ...
    [0.9569 0.4275 0.2627], ...
    [0.8431 0.1882 0.1529], ...
    [0.6471 0      0.1490] };

GRAY = [0.6667, 0.6667, 0.6667];

if mood>=-1 && mood <= 1
    indexA = -10:2:10;
    indexB = 1:11;
    x = 2*round(mood*10/2);
    ind =indexB(indexA == x);
    color = SENTIMENT_COLORS{ind};
else
    color = GRAY;
    
end


end

